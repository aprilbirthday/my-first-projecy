<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SppSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('spp')->insert([
            [
                'tahun' => '2021',
                'nominal' => '1500000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'tahun' => '2022',
                'nominal' => '1600000',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            // Add more entries as needed
        ]);
    }
}
