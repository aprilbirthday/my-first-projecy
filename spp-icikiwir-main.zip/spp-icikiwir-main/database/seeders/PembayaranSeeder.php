<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Pembayaran;
use App\Models\Petugas;
use App\Models\Siswa;

class PembayaranSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $petugas = Petugas::where('kode_petugas', 'PTG001')->first();
        $siswa = Siswa::where('kode_siswa', 'SIS001')->first();

        if ($petugas && $siswa) {
            Pembayaran::create([
                'kode_pembayaran' => 'PMB001',
                'petugas_id' => $petugas->id,
                'siswa_id' => $siswa->id,
                'nisn' => $siswa->nisn,
                'tanggal_bayar' => '2024-01-01',
                'bulan_bayar' => 'Januari',
                'tahun_bayar' => '2024',
                'jumlah_bayar' => 1500000,
            ]);
        }
    }
}
