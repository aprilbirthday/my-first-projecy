<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Create roles
        $adminRole = Role::create(['name' => 'admin']);
        $petugasRole = Role::create(['name' => 'petugas']);
        $siswaRole = Role::create(['name' => 'siswa']);

        // Create permissions
        // Add your permissions here if any, example:
        // Permission::create(['name' => 'manage users']);

        // Create users
        $admin = User::create([
            'username' => 'admin123',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
        ]);
        $admin->assignRole($adminRole);

        $petugas = User::create([
            'username' => 'elaina123',
            'email' => 'petugas@example.com',
            'password' => Hash::make('password'),
        ]);
        $petugas->assignRole($petugasRole);

        $siswa = User::create([
            'username' => 'diva123',
            'email' => 'siswa@example.com',
            'password' => Hash::make('password'),
        ]);
        $siswa->assignRole($siswaRole);
    }
}
