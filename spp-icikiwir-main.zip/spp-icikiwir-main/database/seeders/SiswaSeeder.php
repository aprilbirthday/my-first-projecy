<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Siswa;
use App\Models\User;
use App\Models\Kelas;

class SiswaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::where('username', 'diva123')->first();
        $kelas = Kelas::where('nama_kelas', 'XII RPL 1')->first();

        if ($user && $kelas) {
            Siswa::create([
                'kode_siswa' => 'SIS001',
                'nisn' => '1234567890',
                'nis' => '0987654321',
                'nama_siswa' => 'Diva',
                'jenis_kelamin' => 'Perempuan',
                'alamat' => 'Jl. Merdeka No. 1',
                'no_telepon' => '081234567890',
                'user_id' => $user->id,
                'kelas_id' => $kelas->id,
            ]);
        }
    }
}
