<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Petugas;
use App\Models\User;

class PetugasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Assuming user with id 2 is petugas, adjust according to your needs
        $user = User::where('username', 'elaina123')->first();

        if ($user) {
            Petugas::create([
                'user_id' => $user->id,
                'kode_petugas' => 'PTG001',
                'nama_petugas' => 'Elaina', // Add name for petugas
                'jenis_kelamin' => 'Perempuan'
            ]);
        }

        // Additional petugas seeding for other users if needed
        $user2 = User::where('username', 'admin123')->first();
        if ($user2) {
            Petugas::create([
                'user_id' => $user2->id,
                'kode_petugas' => 'PTG002',
                'nama_petugas' => 'Budi', // Example name for another petugas
                'jenis_kelamin' => 'Laki-laki'
            ]);
        }
    }
}
